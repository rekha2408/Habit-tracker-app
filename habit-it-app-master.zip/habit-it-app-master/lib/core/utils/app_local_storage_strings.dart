class AppLocalStorageKeys {
  static const String app = "APP/APP";
  static const String user = "APP/USER";
  static const String habitInit = "APP/HABIT/INIT/";
  static const String habitMonth = "APP/HABIT/MONTH/";
  static const String habitMonthInit = "APP/HABIT/MONTH/INIT";
}
