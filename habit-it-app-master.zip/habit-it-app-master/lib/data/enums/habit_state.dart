enum HabitState {
  CREATED,
  DONE,
  NOT_DONE,
  SUSPENDED,
}